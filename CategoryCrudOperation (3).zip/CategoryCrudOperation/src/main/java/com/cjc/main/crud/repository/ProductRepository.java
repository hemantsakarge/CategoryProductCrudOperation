package com.cjc.main.crud.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cjc.main.crud.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>{

	public  Product findByPid(int pid);
	
}
